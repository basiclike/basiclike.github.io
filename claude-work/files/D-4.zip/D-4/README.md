# D-4 실습 자료 안내(강사용)

- `zip-A-check-before-done.zip`, `zip-B-check-before-done.zip`: 3단계 "둘 가운데 올라가지 않을 것 고르기"에 씁니다. A는 안에 `check-before-done/SKILL.md`처럼 Skill 폴더가 맨 위에 있고, B는 `SKILL.md`만 맨 위에 있습니다. 도움말 기준으로 올라가는 것은 A입니다. 학습자는 두 파일을 파일 탐색기에서 두 번 눌러 안을 비교합니다.
- `before-date-rule/`, `after-date-rule/`: 4단계 대조의 본보기입니다. 두 SKILL.md는 "확인한 날은 YYYY-MM-DD로 적는다." 한 줄만 다릅니다. Claude가 고친 파일에 이 한 줄 말고 다른 줄이 바뀌었으면 학습자가 찾아야 할 어긋남입니다.
