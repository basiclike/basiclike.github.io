이 폴더는 Claude Work 과정의 시작 자료인 조사 보고서 `kiosk-research.md`와 같은 내용의 Word 파일 `kiosk-research.docx`를 담았습니다.
두 파일을 `C:\kiosk-project`에 넣어 씁니다.
