# Obsidian 설치하고 학습 자료 폴더 열기

## 설치

- Ubuntu에서는 Obsidian 사이트에서 `.deb` 파일을 다운로드해 설치합니다.
- 설치한 앱은 다시 시작할 때 스스로 업데이트됩니다.

## Vault 열기

- Obsidian은 노트를 담은 폴더 하나를 Vault로 엽니다.
- 시작 화면의 `Open folder as vault` 줄에서 `Open`을 클릭해 `~/study-notes` 폴더를 고릅니다.
- Obsidian은 폴더 안의 파일을 그대로 보여 줍니다. 파일 관리자에서 넣은 파일도 바로 목록에 나타납니다.

## 화면의 다섯 영역

1. 리본: 창 맨 왼쪽의 세로 아이콘 막대입니다.
2. 왼쪽 사이드바: 파일 목록과 검색이 있습니다.
3. 편집 영역: 노트를 쓰고 읽는 가운데 영역입니다.
4. 오른쪽 사이드바: 개요(Outline) 같은 도구가 열립니다.
5. 상태 표시줄: 창 맨 아래에 글자 수 같은 정보가 보입니다.

## 바꾼 설정

- 테마: `Settings`의 `Appearance`에서 Minimal 테마를 설치했습니다.
- 플러그인: `Community plugins`에서 Minimal Theme Settings를 설치하고 켰습니다. 커뮤니티 플러그인은 개인이 만든 것이라 제작자를 확인한 뒤 설치합니다.
- 개요: `Core plugins`에서 `Outline`을 켜고, `Hotkeys`에서 단축키를 정했습니다.
